package com.example.whiteboardtest;

import android.view.View;
import android.view.ViewGroup;

import java.util.Date;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;

class MessageRecyclerAdapter extends Adapter<MessageRecyclerAdapter.MessageViewHolder> {
    private List<Message> messages;
    public void setData(List<Message> messages){
        this.messages = messages;
        notifyItemRangeInserted();
    }

    @NonNull
    @Override
    public MessageViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        return new MessageViewHolder(parent);
    }

    @Override
    public void onBindViewHolder(@NonNull MessageViewHolder holder, int position) {

    }

    @Override
    public int getItemCount() {
        return 0;
    }

    class MessageViewHolder extends RecyclerView.ViewHolder {
        public String uuid;
        public Date date;
        public String name;
        public String subject;

        public MessageViewHolder(@NonNull View itemView) {
            super(itemView);
        }
    }

}
