package com.example.whiteboardtest;

import android.util.Log;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.Random;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

public class MessageGenerator implements Runnable {
    private final static String TAG = "MessageGenerator";

    private MutableLiveData<Message> liveMessage = new MutableLiveData<>();
    @Override
    public void run() {
        while(true) {
            try {
                Random ran = new Random();
                Thread.sleep((ran.nextInt(6) + 5) * 1000);

                Message message = new Message();
                Thread currentThread = Thread.currentThread();
                message.setUuid(currentThread.getName());
                message.setDate(new Date());
                Log.e(TAG, "NewMessage" + message.getUuid() + " " + message.getDate().getTime());
                liveMessage.postValue(message);
            } catch (InterruptedException iex) {
                Log.e(TAG, iex.toString());
            }
        }
    }

    public LiveData<Message> getLiveMessage(){
        return liveMessage;
    }
}
