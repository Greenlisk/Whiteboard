package com.example.whiteboardtest;

import java.util.Date;

public class Message implements Comparable<Message>{
    private String uuid;
    private Date date;
    private String name;
    private String subject;

    @Override
    public int compareTo(Message o) {
        int ret = 0;
        long result = this.date.getTime() - o.getDate().getTime();
        if (result > 0){
            ret = -1;
        } else {
            ret = 1;
        }
        return ret;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }
}
