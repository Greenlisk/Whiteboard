package com.example.whiteboardtest;

public class MessageRecyclerAdapterImpl extends MessageRecyclerAdapter {
}
