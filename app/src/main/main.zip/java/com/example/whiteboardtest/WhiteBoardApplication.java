package com.example.whiteboardtest;

import android.app.Application;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class WhiteBoardApplication extends Application {

    ExecutorService executorService = Executors.newFixedThreadPool(5);
    @Override
    public void onCreate() {
        super.onCreate();
    }

    public List<MessageGenerator> getGenerators(){
        ArrayList<MessageGenerator> generatorsList = new ArrayList<>();
        for(int i = 0 ; i < 5; ++i){
            MessageGenerator generator = new MessageGenerator();
            generatorsList.add(generator);
            executorService.execute(generator);
        }
        return generatorsList;
    }

}
