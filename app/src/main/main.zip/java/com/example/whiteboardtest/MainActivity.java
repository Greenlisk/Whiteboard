package com.example.whiteboardtest;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import android.os.Bundle;
import android.util.Log;

import java.util.ArrayList;
import java.util.Set;

public class MainActivity extends AppCompatActivity implements Observer<Set<Message>> {
    private final static String TAG = "MainActivity";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        MainViewModel viewmodel = new ViewModelProvider(this).get(MainViewModel.class);
        viewmodel.getMessages().observe(this, this);
    }

    @Override
    public void onChanged(Set<Message> messages) {
        ArrayList<Message> list = new ArrayList(messages);
        for(Message message : list){
            Log.e(TAG, "Message;  " + message.getDate().getTime());
        }
    }
}