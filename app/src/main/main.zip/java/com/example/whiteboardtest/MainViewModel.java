package com.example.whiteboardtest;

import android.app.Application;
import android.util.Log;

import java.util.ArrayList;
import java.util.Set;
import java.util.TreeSet;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MediatorLiveData;
import androidx.lifecycle.Observer;

public class MainViewModel extends AndroidViewModel {
    private final static String TAG = "MainViewModel";
    private WhiteBoardApplication app;
    private MediatorLiveData<Set<Message>> dataStorage = new MediatorLiveData<>();

    public MainViewModel(Application application){
        super(application);
        dataStorage.setValue(new TreeSet<Message>());
        app = (WhiteBoardApplication)application;
        for (MessageGenerator generator : app.getGenerators()){
            Observer<? super Message> observer =  new Observer<Message>() {
                @Override
                public void onChanged(Message message) {
                    Set<Message> value = dataStorage.getValue();
                    value.add(message);
                    dataStorage.setValue(value);
                    Log.e(TAG, "Message accepted: " + dataStorage.getValue().size());
                }
            };
            dataStorage.addSource(generator.getLiveMessage(), observer);
        }
    }

    public LiveData<Set<Message>> getMessages(){
        return dataStorage;
    }
}
